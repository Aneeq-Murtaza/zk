from django.urls import path
from . import views

urlpatterns = [
    path('create_elasticsearch_index/', views.create_elasticsearch_index, name='create_elasticsearch_index'),
    path('index_data_to_elastic_search/', views.index_data_to_elastic_search, name='index_data_to_elastic_search'),
    path('getIOCS/', views.getIOCS, name='getIOCS'),
    path('fetchAttendance/', views.fetch_attendance, name='fetchAttendance'),
    path('index/',views.index, name='index')
]