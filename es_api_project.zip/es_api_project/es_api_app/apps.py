from django.apps import AppConfig


class EsApiAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'es_api_app'
