from django.shortcuts import render
import requests
from django.http import JsonResponse
from django.conf import settings
import json
from rest_framework.decorators import api_view
from zk import ZK, const
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build
import os
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Create your views here.

def create_elasticsearch_index(request):
    url = f"http://{settings.ELASTICSEARCH_HOST}:{settings.ELASTICSEARCH_PORT}/testing_indices"
    print(str(url))
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': settings.ELASTICSEARCH_API_KEY,
    }
    
    response = requests.put(url, headers=headers)
    
    if response.status_code == 200:
        return JsonResponse({'message': 'Elasticsearch index created successfully'})
    else:
        return JsonResponse({'message': 'Failed to create Elasticsearch index'}, status=500)
    
@api_view(['POST'])    
def index_data_to_elastic_search(request):
    try:
        # Parse the JSON data from the request body
        data = json.loads(request.body.decode('utf-8')  )
    except json.JSONDecodeError:
        return JsonResponse({'message': 'Invalid JSON data in the request body'}, status=400)

        # Define the Elasticsearch URL for the specific index where you want to add a document
    index_url = f"http://{settings.ELASTICSEARCH_HOST}:{settings.ELASTICSEARCH_PORT}/testing_indices/_doc"
    headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': settings.ELASTICSEARCH_API_KEY,
        }

    try:
        response = requests.post(index_url, headers=headers, json=data)
        if response.status_code == 201:
            return JsonResponse({'message': 'Document indexed successfully in Elasticsearch'})
        else:
            return JsonResponse({'message': 'Failed to index document in Elasticsearch'}, status=500)
    except Exception as e:
        return JsonResponse({'message': f'Error: {str(e)}'}, status=500)

@api_view(['GET']) 
def getIOCS(request):
    
    print("Inside Function")
    #return JsonResponse({'msg':'testing the route...'})
    misp_url = 'https://192.168.17.17'
    misp_key = 'PsXjjrhWDhSmXeuSvIpGYZ84acLPO0quAPKeihnl'

    search_params = {
    #"eventid": 1,
    "returnFormat": "json"
    }

    print(search_params)

    headers = {
        "Authorization": misp_key,
        "Content-Type": "application/json",
    }

    counter=0
    while True:
        print("Inside Loop")
        
        counter+=1
        search_params['eventid'] = counter
        response = requests.post(f"{misp_url}/attributes/restSearch", json=search_params, headers=headers, verify=False)
        if response.status_code == 200:
            response_data = response.json()
            attributes_data = response_data.get('response', {}).get('Attribute', [])
            
            for attribute in attributes_data:
                category = attribute.get('category')
                attr_type = attribute.get('type')
                value = attribute.get('value')
                event_id=attribute.get('event_id')
                print(f"Category: {category}, Type: {attr_type}, Value: {value}, Event ID: {event_id}")
                post_IOCS_to_elastic_search(category, attr_type, value, event_id)
        else:
            print(f"Failed to retrieve attributes. Status code: {response.status_code}")
            return JsonResponse({'result': 'Attributes finished ...'})
    
    return JsonResponse({'result': 'Completed fetching IOCS ...'})


def post_IOCS_to_elastic_search(category, attr_type, value, event_id):
    try:
        # Parse the JSON data from the request body
        data = {
            'category': category,
            'attr_type': attr_type,
            'value': value,
            'event_id': event_id
        }
    except json.JSONDecodeError:
        return JsonResponse({'message': 'Invalid JSON data in the request body'}, status=400)

        # Define the Elasticsearch URL for the specific index where you want to add a document
    index_url = f"http://{settings.ELASTICSEARCH_HOST}:{settings.ELASTICSEARCH_PORT}/iocs_index_data/_doc"
    headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': settings.ELASTICSEARCH_API_KEY,
        }

    try:
        response = requests.post(index_url, headers=headers, json=data)
        if response.status_code == 201:
            return JsonResponse({'message': 'Document indexed successfully in Elasticsearch'})
        else:
            return JsonResponse({'message': 'Failed to index document in Elasticsearch'}, status=500)
    except Exception as e:
        return JsonResponse({'message': f'Error: {str(e)}'}, status=500)


# @api_view(['GET']) 
# def fetch_attendance(request):
#     try:
#         # connect to device
#         conn = zk.connect()
#         # disable device, this method ensures no activity on the device while the process is run
#         conn.disable_device()
#         # another commands will be here!
#         # Example: Get All Users
#         users = conn.get_users()
#         for user in users:
#             privilege = 'User'
#             if user.privilege == const.USER_ADMIN:
#                 privilege = 'Admin'
#             print ('+ UID #{}'.format(user.uid))
#             print ('  Name       : {}'.format(user.name))
#             print ('  Privilege  : {}'.format(privilege))
#             print ('  Password   : {}'.format(user.password))
#             print ('  Group ID   : {}'.format(user.group_id))
#             print ('  User  ID   : {}'.format(user.user_id))

#         # Test Voice: Say Thank You
#         # conn.test_voice()
#         # re-enable device after all commands already executed
#         conn.enable_device()
#         # conn.read_sizes()
#         print(conn)
#         # #also:
#         # conn.users
#         # conn.fingers
#         # conn.records
#         # conn.users_cap
#         # conn.fingers_cap
#             # Get attendances (will return list of Attendance object)
#         attendances = conn.get_attendance()
#         entries = re.findall(r'<Attendance>: \d+ : [\d\s\-:]+ \(\d+,\s*\d+\)', str(attendances))
#         i = 0
#         for entry in entries:
#             # Split each entry into its components
#             components = re.split(r': | \(', entry)
            
#             # Extracting values
#             attendance_type = components[0].strip('<> ')
#             count = components[1].strip()
#             date_time = components[2]
#             values = components[3].strip(') ').split(', ')
#             i = i+1
#             print(i)
#             # Printing extracted values
#             print("Attendance Type:", attendance_type)
#             print("Count:", count)
#             print("Date and Time:", date_time)
#             print("Values:", values)
#             print("...")
#             parsed_checkinout= int(values[1])
#             if(parsed_checkinout==0):
#                 value="IN"
#             else:
#                 value="OUT"
#             print(value)
#             url = f"https://erpnext-81648-0.cloudclusters.net/api/method/erpnext.hr.doctype.employee_checkin.employee_checkin.add_log_based_on_employee_field?employee_field_value={count}&timestamp={date_time}&device_id=machine1&log_type={value}&skip_auto_attendance=0&employee_fieldname=attendance_device_id"

#             payload = {}
#             headers = {
#             'Authorization': 'token e360e10b0d66a9f:e2c398dac4457f4'
#             }

#             response = requests.request("POST", url, headers=headers, data=payload,verify=False)

#             print(response.text)
            
#         # Clear attendances records
#         return JsonResponse({'result': "attendances.."})
#     except Exception as e:
#         print ("Process terminate : {}".format(e))
#     finally:
#         if conn:
#             conn.disconnect()
#     return JsonResponse({"Error": "Error Occured"})
@csrf_exempt
@api_view(['POST']) 
def fetch_attendance(request):
    last_date = ""
    last_datetime = datetime.now()
    try:
        with open(os.path.join(BASE_DIR, 'config', 'date.txt'),'r') as r:
            last_date =  r.read()
            last_datetime = datetime.strptime(last_date, '%Y-%m-%d %H:%M:%S')
    except:
        last_date = "2020-12-01 14:37:47"
        last_datetime = datetime.strptime(last_date, '%Y-%m-%d %H:%M:%S')
        
    print(last_datetime)

    SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
    SERVICE_ACCOUNT_FILE = os.path.join(BASE_DIR, 'config', 'attendanceapi-407210-c9724fa83217.json')
    spreadsheet_id = '1lSOMq_ea5LLuunENL-JnnFbX78DxZUY1p7yUJvR9Izs'

    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    service = build('sheets', 'v4', credentials=creds)
    range_name1 = 'Sheet1!A2:Z'  # Change the range to include all rows after A2

    # Clear the data after A2
    service.spreadsheets().values().clear(
        spreadsheetId=spreadsheet_id, range=range_name1
    ).execute()

    print('Entries after A2 removed.')

    # Spreadsheet ID and range
    range_name = 'Sheet1!A2'

    conn = None
    url = 'https://erpnext-81648-0.cloudclusters.net/api/resource/Employee'
    headers = {
        'Authorization': 'token e360e10b0d66a9f:e2c398dac4457f4',  # Replace with your actual access token
    }

    params = {
        'fields': '["name","company","employee_name","user_id","attendance_device_id"]',
        'limit_page_length':500
    }

    response = requests.get(url, headers=headers, params=params, verify=False)
    json_response = response.json()
    dinct = {}
    for key in json_response['data']:
        id =  key['attendance_device_id']
        employee = key['name']
        dinct[id] = employee

    print("dinct: ",len(dinct))
    # create ZK instance
    zk = ZK('182.188.38.219', port=4370, timeout=5, password=2719, force_udp=False, ommit_ping=False)
    try:
        # connect to device
        conn = zk.connect()
        print(conn)
        # disable device, this method ensures no activity on the device while the process is run
        conn.disable_device()
        # another commands will be here!
        # Example: Get All Users
        users = conn.get_users()
        for user in users:
            privilege = 'User'
            if user.privilege == const.USER_ADMIN:
                privilege = 'Admin'
            print('+ UID #{}'.format(user.uid))
            print('  Name       : {}'.format(user.name))
            print('  Privilege  : {}'.format(privilege))
            print('  Password   : {}'.format(user.password))
            print('  Group ID   : {}'.format(user.group_id))
            print('  User  ID   : {}'.format(user.user_id))

        # Test Voice: Say Thank You
        conn.test_voice()
        # re-enable device after all commands already executed
        conn.enable_device()
        conn.read_sizes()

        # Extracted attendance values
        attendances = conn.get_attendance()
        print("Attendances: ",len(attendances))
        entries = re.findall(r'<Attendance>: \d+ : [\d\s\-:]+ \(\d+,\s*\d+\)', str(attendances))
        print("Entries: ",len(entries))
        i = 0
        # Create a list to hold rows of data
        rows_to_write = []
        date = datetime.now()
        for entry in entries:
            # Split each entry into its components
            components = re.split(r': | \(', entry)

            # Extracting values
            attendance_type = components[0].strip('<> ')
            count = components[1].strip()
            date_time = components[2]
            values = components[3].strip(') ').split(', ')
            i = i + 1

            # # Printing extracted values
            # print(i)
            # print("Attendance Type:", attendance_type)
            # print("Count:", count)
            # print("Date and Time:", date_time)
            # print("Values:", values)
            # print("...")
            date_time = datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S') 
            date = date_time
            parsed_checkinout = int(values[1])
            if parsed_checkinout == 0:
                value = "IN"
            elif parsed_checkinout == 4:
                value = "IN"
            elif parsed_checkinout == 5:
                value = "OUT"
            else:
                value = "OUT"
            try:
                if date_time > last_datetime:
                # Append the extracted values to the list
                    rows_to_write.append([dinct[count], str(date_time), value])
            except Exception as e:
                print(e)

        print(len(rows_to_write))
        print(date)
        with open(os.path.join(BASE_DIR, 'config', 'date.txt'), 'w') as file:
            # Write some text to the file
            file.write(str(date))

        body = {
            'values': rows_to_write
        }

        result = service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id, range=range_name,
            valueInputOption='RAW', body=body
        ).execute()

        print('{0} cells updated.'.format(result.get('updatedCells')))
        if conn:
            conn.disconnect()
        return JsonResponse({"Success":"Synced Sucessfully"})
    except Exception as e:
        print("Process terminate : {}".format(e))
        if conn:
            conn.disconnect()
        return JsonResponse({"Error":"Error Occured"})

def index(request):
    return render(request, 'index.html')   
   


